var WINDOW_SWITCH_LOGIN_1_2 = '#div_login, #div_forgotPin';
var WINDOW_SWITCH_LOGIN_2_3 = '#div_forgotPin, #div_sendPin';
var WINDOW_SWITCH_REGISTER_1_2 = '#div_registerInfo, #div_registerLikes';
var WINDOW_SWITCH_REGISTER_2_3 = '#div_registerLikes, #div_registerStruggles';
var WINDOW_SWITCH_REGISTER_3_4 = '#div_registerStruggles, #div_registerContacts';
var WINDOW_SWITCH_REGISTER_4_5 = '#div_registerContacts, #div_registerComplete';
var WINDOW_SWITCH_MAIN_12_13 = '#div_taskActivityScreen, #div_activityRecScreen';
var WINDOW_SWITCH_MAIN_12_15 = '#div_taskActivityScreen, #div_selectTaskScreen';
var WINDOW_SWITCH_MAIN_13_14 = '#div_activityRecordedScreen, #div_activityRecScreen';
var WINDOW_SWITCH_MAIN_16_17 = '#div_taskRecorderScreen, #div_taskRecordCompleteScreen';

var WEEK_DAY = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];