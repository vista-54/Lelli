var WINDOW_SWITCH_LOGIN_1_2 = '#div_login, #div_forgotPin';

var WINDOW_SWITCH_LOGIN_2_3 = '#div_forgotPin, #div_sendPin';

var WINDOW_SWITCH_REGISTER_1_2 = '#div_registerInfo, #div_registerLikes';

var WINDOW_SWITCH_REGISTER_2_3 = '#div_registerLikes, #div_registerStruggles';

var WINDOW_SWITCH_REGISTER_3_4 = '#div_registerStruggles, #div_registerContacts';

var WINDOW_SWITCH_REGISTER_4_5 = '#div_registerContacts, #div_registerComplete';

var WINDOW_SWITCH_MAIN_12_13 = '#div_taskActivityScreen, #div_activityRecScreen';

var WINDOW_SWITCH_MAIN_13_14 = '#div_activityRecordedScreen, #div_activityRecScreen';

var WINDOW_SWITCH_MAIN_16_17 = '#div_taskRecorderScreen, #div_taskRecordCompleteScreen';

var WINDOW_SWITCH_MAIN_19_20 = '#div_dontWorryScreen, #div_lowMoodRecScreen';

var WINDOW_SWITCH_MAIN_20_14 = '#div_taskActivityScreen, #div_activityRecordedScreen';

var WINDOW_SWITCH_EMERGENCY_28_29 = '#div_notAloneScreen, #div_callFriend';

var WINDOW_SWITCH_EMERGENCY_29_30 = '#div_notAloneScreen, #div_callEmergency';

var WINDOW_SWITCH_EMERGENCY_28_32 = '#div_callFriend, #div_didUCallScreen';

var WINDOW_SWITCH_EMERGENCY_32_29 = '#div_didUCallScreen, #div_notAloneScreen';

var WINDOW_SWITCH_EMERGENCY_32_30 = '#div_didUCallScreen, #div_callEmergency';


var WEEK_DAY = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];