var WINDOW_SWITCH_LOGIN_1_2 = '#div_login, #div_forgotPin';
var WINDOW_SWITCH_LOGIN_2_3 = '#div_forgotPin, #div_sendPin';
var WINDOW_SWITCH_REGISTER_1_2 = '#div_registerInfo, #div_registerLikes';
var WINDOW_SWITCH_REGISTER_2_3 = '#div_registerLikes, #div_registerStruggles';
var WINDOW_SWITCH_REGISTER_3_4 = '#div_registerStruggles, #div_registerContacts';
var WINDOW_SWITCH_REGISTER_4_5 = '#div_registerContacts, #div_registerComplete';